
1. Download and install emscripten using the guide from.
   https://emscripten.org/docs/getting_started/downloads.html

2. Add 'emsdk/' directory to the environment, this will need to
   call the emsdk_env from anywhere.

3. Run command `call emsdk_env.bat` to initialize the emsdk env
   on windows, for other platform see emscripten docs.

4. Run 'python compile.py' to run compile.

   

